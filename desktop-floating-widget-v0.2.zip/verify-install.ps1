﻿# 鏍￠獙鑴氭湰锛氱‘璁ゆ偓娴寕浠?5 涓枃浠跺凡姝ｇ‘瀹夎
# 鐢ㄦ硶锛歱owershell -ExecutionPolicy Bypass -File verify-install.ps1 -AppDir "搴旂敤瀹夎鐩綍"
param([string]$AppDir)

$ErrorActionPreference = 'Continue'

if (-not $AppDir) {
    $AppDir = Read-Host '璇疯緭鍏?DeepSeek Harness Desktop 瀹夎鐩綍锛堝寘鍚?DeepSeek Harness.exe 鐨勬枃浠跺す锛?
}
if (-not (Test-Path (Join-Path $AppDir 'DeepSeek Harness.exe'))) {
    Write-Host "[!] 鏈壘鍒?DeepSeek Harness.exe锛岃妫€鏌ョ洰褰曪細$AppDir" -ForegroundColor Red
    exit 1
}

$srcDir = Join-Path $AppDir 'resources\app\src'
if (-not (Test-Path $srcDir)) {
    Write-Host "[!] 鏈壘鍒?resources\app\src锛岀洰褰曞彲鑳戒笉瀹屾暣锛?srcDir" -ForegroundColor Red
    exit 1
}

$expected = @{
    'floating-panel.js'     = 'C77F83D5FF798882E19EECA969AED65212C23AC9AE2047FDC45E1315862C201B'
    'floating-preload.js'   = '3B2E06F16824B2FE4E3A40E2E4FBF9A51B3F2DBE13337F1EE1982C72ECE65A7E'
    'floating-trigger.html' = '275A8A059C62CB2F6DB38FF4FCA9CF6E3C65271F68A4E8B5DEF59E5ADA2BF702'
    'dsh-service.js'        = 'F19B9AEE38B75C0105630CB7C7743687428DA7A545B0760D9C18235E92810045'
    'main.js'               = 'B0FA384B863AE5DB3D343FE5F44EE65D52C651BF0A1E437C1323E05BBF229827'
}

$allOk = $true
foreach ($name in $expected.Keys | Sort-Object) {
    $path = Join-Path $srcDir $name
    if (-not (Test-Path $path)) {
        Write-Host "$name : 缂哄け!" -ForegroundColor Red
        $allOk = $false
        continue
    }
    $actual = (Get-FileHash $path -Algorithm SHA256).Hash
    if ($actual -eq $expected[$name]) {
        Write-Host "$name : OK" -ForegroundColor Green
    } else {
        Write-Host "$name : 鍝堝笇涓嶅尮閰嶏紙鏂囦欢鍙兘鏉ヨ嚜鍏朵粬鐗堟湰锛? -ForegroundColor Yellow
        $allOk = $false
    }
}

$running = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'DeepSeek Harness' }
if ($running) {
    Write-Host '' -ForegroundColor Yellow
    Write-Host "[!] DeepSeek Harness 姝ｅ湪杩愯鈥斺€旀柊鏂囦欢闇€瑕侀噸鍚簲鐢ㄦ墠浼氱敓鏁堛€? -ForegroundColor Yellow
}

if ($allOk) {
    Write-Host ''
    Write-Host '瀹夎鏍￠獙閫氳繃 鉁?閲嶅惎 DeepSeek Harness Desktop 鍗冲彲浣跨敤銆? -ForegroundColor Green
} else {
    Write-Host ''
    Write-Host '[!] 鏈夋枃浠剁己澶辨垨涓嶅尮閰嶏紝璇烽噸鏂板鍒跺悗鍐嶆牎楠屻€? -ForegroundColor Red
}

