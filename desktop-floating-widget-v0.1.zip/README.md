# DeepSeek Harness Desktop — 桌面悬浮挂件（Floating Panel Widget）

在 **DeepSeek Harness Desktop**（Electron 外壳）里加入一个桌面级悬浮挂件：
一块贴在屏幕右缘中间的小白条（三个灰点），点击后从屏幕右侧平滑滑出一块
悬浮板（内含完整的 DeepSeek Harness 会话界面），鼠标移出后自动收起。

> 说明：这是**桌面外壳功能**，不是 dsh 插件市场的 npm 插件（插件市场只分发
> 网页插件；桌面窗口只能由 Electron 外壳创建）。

## 功能

- 平时完全隐藏，桌面干净
- 鼠标移动到屏幕**最右缘的中间区域** → 白色小竖条从屏幕边缘平滑滑出
- 鼠标离开该区域 → 小竖条平滑滑回
- **点击**小竖条 → 悬浮板（宽 ≈ 屏宽 1/5，clamp 360–560px）平滑滑入
  - 面板 = 真正的 DSH 网页界面（同一服务的第二个客户端）
  - 与主窗口共享存储：打开即显示**当前正在进行的会话**；主窗口切换会话时面板自动跟随
  - 右上角注入圆形【收起】按钮（»）
- 鼠标移出面板约 0.5 秒 → 平滑滑出 → 小竖条再出现约 1 秒 → 平滑滑回隐藏
- 置顶于所有应用之上（含壁纸/桌面挂件软件的置顶层，定期重新抬升）
- 主窗口关闭（隐藏到托盘）后挂件照常工作
- 动画：~125Hz 驱动步进 + 缓动曲线，支持 90/120/144Hz 高刷显示器
- 无障碍：`prefers-reduced-motion` 下无动画；触发条不抢键盘焦点

## 文件清单

| 文件 | 类型 | 说明 |
|---|---|---|
| `floating-panel.js` | 新增 | 挂件控制器（窗口创建、滑入滑出动画、边缘感应、自动隐藏、会话跟随） |
| `floating-preload.js` | 新增 | 安全桥接（contextBridge） |
| `floating-trigger.html` | 新增 | 小竖条页面（三个点 + 点击处理） |
| `dsh-service.js` | 修改 | ① 工作目录与 `DSH_HOME` 锚定到应用所在工作区（从任意位置启动都能找到 profile）② 绕过易故障的 .NET 隐藏控制台启动器，直接以 `windowsHide` 启动 ③ 启动超时 60s→120s ④ 启动日志（`%TEMP%\dsh-desktop-service.log`） |
| `main.js` | 修改 | 服务就绪后调用 `startFloatingPanel(serviceUrl)`（两处小改动） |

## 安装（用户侧）

把三个新文件放进桌面应用安装目录的 `resources/app/src/`，并按上述说明修改
`dsh-service.js` 与 `main.js`（本目录已提供改好的完整文件，直接覆盖即可），
然后重启 DeepSeek Harness Desktop。

## 可调参数（`floating-panel.js` 顶部常量）

| 常量 | 默认 | 含义 |
|---|---|---|
| `TRIGGER_W` / `TRIGGER_H` | 12 / 160 | 小竖条宽/高（DIP） |
| `EDGE_ZONE` | 12 | 右缘横向感应距离 |
| `EDGE_BAND_HALF` | 140 | 感应带的纵向半宽（以屏幕中线为中心） |
| `PANEL_MIN_W` / `PANEL_MAX_W` | 360 / 560 | 悬浮板宽度范围（1/5 屏宽夹取） |
| `PANEL_SLIDE_MS` / `STRIP_SLIDE_MS` | 380 / 180 | 面板 / 竖条动画时长 |
| `SLIDE_STEP_MS` | 8 | 动画驱动步进（≈125Hz） |
| `STRIP_POST_PANEL_HIDE_MS` | 1000 | 面板收起后竖条保留时长 |

## 已知取舍（供维护者参考）

- 触发条/面板固定在**主显示器**；副屏不显示。
- 独占全屏应用（游戏）会盖住置顶窗口（Windows 限制），窗口化/最大化正常。
- 12px 触发条会压住其他最大化窗口的最右缘（如滚动条）——"最右侧+置顶"的固有代价。
- 面板与主窗口是**同一会话的两个客户端**：内容实时同步；各自的选择互不实时跟随（面板通过存储桥在切换会话时自动刷新跟随）。
- 触发条窗口刻意**不透明**：透明/分层窗口在壁纸引擎挂钩 DWM/GPU 的机器上可能完全渲染不出来（踩过坑）。
- 动画每帧写入**完整边界**：部分 `setBounds` 在混合 DPI 机器上会让窗口尺寸逐次漂移（越点越大的 bug）。

## 许可

MIT License —— 本挂件代码为原创作品，按 MIT 许可发布，可自由使用、修改、分发。

> 说明：DeepSeek Harness Desktop 是社区开发的**非官方**桌面封装（其包描述即注明
> “An unofficial desktop wrapper for DeepSeek Harness”），并非 DeepSeek 官方产品。
> 本挂件与其同以 MIT 发布，仅表示许可条款一致，不涉及任何官方背书。
